'use client'
import React from 'react'
import D3Example from '../components/D3Example'

const Dashboard = () => {
    return (
        <D3Example width="200" height="200" />
    )
}

export default Dashboard